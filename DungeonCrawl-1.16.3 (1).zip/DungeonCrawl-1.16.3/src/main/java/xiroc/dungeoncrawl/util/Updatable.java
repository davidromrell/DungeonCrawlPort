package xiroc.dungeoncrawl.util;

public interface Updatable {

    void update();

}
